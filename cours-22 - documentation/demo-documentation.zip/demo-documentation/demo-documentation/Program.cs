﻿// hover sur la propriété pour voir la documentation
Calculateur.Multiplicateur = 2;
// hover sur la méthode pour voir la documentation
double resultat = Calculateur.Multiplier(3, 5);
Console.WriteLine(resultat);

resultat = Calculateur.Multiplier(2);
Console.WriteLine(resultat);